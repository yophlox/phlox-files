# GameMakerDecompiler
Decompiles GMS2 games, DO NOT LEAK



hi :)

